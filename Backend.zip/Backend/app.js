const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const cors = require('cors');

const app = express();
const PORT = 8100;
const SECRET_KEY = '12345';

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Set up session
app.use(session({
  secret: SECRET_KEY,
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } 
}));

// Set EJS 
app.set('view engine', 'ejs');
app.set('views', './views');

const users = [
  {
    id: 1,
    username: 'user1',
    password: 'password1'
  }
];

app.get('/', (req, res) => {
  res.render('login');
});

// Login route
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    req.session.user = { id: user.id, username: user.username };

    res.redirect(`https://bayesian.in/login`);
  } else {
    res.status(401).json({ message: 'Invalid credentials' });
  }
});

// Middleware to check if user is logged in
const checkLoggedIn = (req, res, next) => {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/');
  }
};

// Protected route
app.get('/protected', checkLoggedIn, (req, res) => {
  res.render('protected', { username: req.session.user.username });
});

// Logout route
app.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.status(500).json({ message: 'Failed to log out' });
    }
    res.redirect('/');
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
