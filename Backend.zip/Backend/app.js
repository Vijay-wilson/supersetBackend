const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');

const app = express();
const PORT = 8100;
const SECRET_KEY = '12345';

const https = require('https');
const fs = require('fs');
// Load SSL certificate and key
const privateKey = fs.readFileSync('./cert/key.pem', 'utf8');
const certificate = fs.readFileSync('./cert/cert.pem', 'utf8');

const credentials = { key: privateKey, cert: certificate };

// Create HTTPS server
const httpsServer = https.createServer(credentials, app);

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Set up session
app.use(session({
  secret: SECRET_KEY,
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } 
}));

// Set EJS 
app.set('view engine', 'ejs');
app.set('views', './views');

// Hash password before storing in users array
const users = [
  {
    id: 1,
    username: 'user1',
    password: bcrypt.hashSync('password1', 10) 
  }
];

// Track login attempts
const loginAttempts = {};
app.get('/', (req, res) => {
  res.render('login');
});

// Nodemailer 
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'vijaywilsonofficial@gmail.com',
    pass: 'mpoj kgdb eizz hrvw'
  }
});

// Function to send email
const sendEmail = (username) => {
  const mailOptions = {
    from: 'vijaywilsonofficial@gmail.com',
    to: 'vijaywilsonofficial@gmail.com',
    subject: 'Login attempts exceeded',
    text: `Too many unsuccessful login attempts for username: ${username}. Account blocked for 1 hour.`
  };

  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
};

// Login route
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Check if the user is already blocked
  if (loginAttempts[username] && loginAttempts[username].attempts >= 3) {
    const timeDiff = Date.now() - loginAttempts[username].lastAttempt;
    if (timeDiff < 3600000) { // 3600000 milliseconds = 1 hour
      sendEmail(username); 
      // return res.status(429).json({ message: 'Too many login attempts. Try again later.' });
      return res.render('toomanyattempts');
    } else {
      // Reset login attempts
      delete loginAttempts[username];
    }
  }

  const user = users.find(u => u.username === username);

  if (user && bcrypt.compareSync(password, user.password)) {
    // Reset login attempts on successful login
    if (loginAttempts[username]) {
      delete loginAttempts[username];
    }
    req.session.user = { id: user.id, username: user.username };
    res.redirect('https://bayesian.in/login');
  } else {
    // Record failed attempt
    if (!loginAttempts[username]) {
      loginAttempts[username] = {
        attempts: 0,
        lastAttempt: Date.now()
      };
    }
    loginAttempts[username].attempts++;
    // res.status(401).json({ message: 'Invalid credentials' });
    res.render('invalidCredentials');
  }
});

// Middleware to check if user is logged in
const checkLoggedIn = (req, res, next) => {
  if (req.session.user) {
    next();
  } else {
    res.redirect('/');
  }
};

// Protected route
app.get('/protected', checkLoggedIn, (req, res) => {
  res.render('protected', { username: req.session.user.username });
});

// Logout route
app.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.status(500).json({ message: 'Failed to log out' });
    }
    res.redirect('/');
  });
});

// Start the server
httpsServer.listen(PORT, () => {
  console.log(`Https Server is running on port ${PORT}`);
});
